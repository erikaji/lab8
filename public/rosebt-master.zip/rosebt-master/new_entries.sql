UPDATE rbt SET id_user=3 WHERE id_rbt=301;
UPDATE rbt SET created_at='2014-05-25 19:51:59' WHERE id_rbt=301;
UPDATE rbt SET rose='Went to Napa with Yiju, Krystal, and Laura. Wine country is beautiful, and we had such blast talking about everything from how we look like our moms to our graduation plans next year!' WHERE id_rbt=301;
UPDATE rbt SET bud='I get to go hiking with friends tomorrow near Stinson Beach :)' WHERE id_rbt=301;
UPDATE rbt SET thorn='I\'m really struggling to keep up with my philosophy classes. I\'ve lost all motivation to work.' WHERE id_rbt=301;
UPDATE rbt SET photo_tag='rose' WHERE id_rbt=301;

UPDATE rbt SET id_user=3 WHERE id_rbt=291;
UPDATE rbt SET created_at='2014-02-18 16:20:01' WHERE id_rbt=291;
UPDATE rbt SET rose='Had an awesome time at dinner with Anna today. We laughed a lot and ate berries and ice cream.' WHERE id_rbt=291;
UPDATE rbt SET bud='My friend Sam is back from Japan!! She\'ll be stopping by to visit before she goes back to St. Louis to start her MD/PhD :)' WHERE id_rbt=291;
UPDATE rbt SET thorn='Had a pretty awful conversation with a close friend. I used to think that friendship was simple, but I guess sometimes it really is not. I\'m still hoping things will get better.' WHERE id_rbt=291;
UPDATE rbt SET photo_tag='bud' WHERE id_rbt=291;

UPDATE rbt SET id_user=3 WHERE id_rbt=281;
UPDATE rbt SET created_at='2014-04-13 21:34:23' WHERE id_rbt=281;
UPDATE rbt SET rose='Anna and I went to San Francisco! We ate delicious cheesecake and made daisy chains in the park and it was glorious.' WHERE id_rbt=281;
UPDATE rbt SET bud='Renjie is coming back from Boston tonight :)' WHERE id_rbt=281;
UPDATE rbt SET thorn='While we were in Golden Gate Park, someone broke into my car and stole my backpack, including my laptop. I\'m very thankful that my dad has an extra laptop at work that I can use, but it still sucks.' WHERE id_rbt=281;
UPDATE rbt SET photo_tag='rose' WHERE id_rbt=281;

UPDATE rbt SET created_at='2014-05-18 18:33:48' WHERE id_rbt=321;
UPDATE rbt SET rose='SBS ladies had tea together :)' WHERE id_rbt=321;
UPDATE rbt SET bud='I\'m meeting with my Viennese Ball "successors" one last time to pass down my infinite knowledge :P' WHERE id_rbt=321;
UPDATE rbt SET thorn='Coding sometimes takes a LOT longer than I think it will. Ugh.' WHERE id_rbt=321;
UPDATE rbt SET photo_tag='rose' WHERE id_rbt=321;

UPDATE rbt SET created_at='2014-05-31 18:33:48' WHERE id_rbt=331;
UPDATE rbt SET rose='You won\'t BELIEVE where I got this picture! Hint: it\'s a well-known campus landmark, and it\'s very high up ;)' WHERE id_rbt=341;
UPDATE rbt SET bud='I ordered some squishables and they\'re coming soon!!!' WHERE id_rbt=341;
UPDATE rbt SET thorn='I have to get up early in the morning tomorrow, and I feel like I haven\'t slept in ages...' WHERE id_rbt=341;
UPDATE rbt SET photo_tag='bud' WHERE id_rbt=431;

UPDATE rbt SET created_at='2014-05-18 18:33:48' WHERE id_rbt=311;
UPDATE rbt SET rose='Maker Faire was really cool! My favorite thing was this glowing cat.' WHERE id_rbt=311;
UPDATE rbt SET bud='Attending a friend\'s composition concert' WHERE id_rbt=311;
UPDATE rbt SET thorn='It\'s been tricky finding users for our user testing this week for 247' WHERE id_rbt=311;

UPDATE rbt SET created_at='2014-05-01 18:33:48' WHERE id_rbt=631;
UPDATE rbt SET rose='I got to hang out with my neighbor and her cat this weekend!' WHERE id_rbt=431;
UPDATE rbt SET bud='I get to hang out with my little and her roommate today :)' WHERE id_rbt=431;
UPDATE rbt SET thorn='Sometimes I just wish my friends would get along :(' WHERE id_rbt=631;

UPDATE rbt SET created_at='2014-05-20 18:33:48' WHERE id_rbt=531;
UPDATE rbt SET id_user=1 WHERE id_rbt=451;

DELETE FROM rbt WHERE id_rbt = 511;



